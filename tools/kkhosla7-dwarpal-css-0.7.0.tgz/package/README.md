# dwarapal-css

Shared CSS language pack and CSS rules for `@kkhosla7/dwarpal-core`.

The package owns the PostCSS parser. It does not depend on Svelte.
