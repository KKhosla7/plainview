# dwarpal-core

Artifact-based verification engine and the `dwarpal` CLI.

The core is language-agnostic. It owns artifacts, language-pack contracts, file
discovery, config loading, the runner, reporting, and integrity verification. It
does not own CSS or Svelte parsers.

## Install

```bash
npm install --save-dev @kkhosla7/dwarpal-core @kkhosla7/dwarpal-js
```

Configure the private scope once:

```ini
# .npmrc
@kkhosla7:registry=https://npm.pkg.github.com
```

Set `NODE_AUTH_TOKEN` to a GitHub token with `read:packages` for private installs.

## Usage

```bash
node ./bin/dwarpal.js check --config ./ast-slop.config.mjs
node ./bin/dwarpal.js check --config ./ast-slop.config.mjs --root ../plainview src scripts tests
node ./bin/dwarpal.js check --config ./ast-slop.config.mjs --json
```

## Config

```js
export default {
  rulePacks: ['@kkhosla7/dwarpal-js'],
  include: ['src', 'scripts', 'tests'],
  exclude: ['node_modules', 'dist', '.git', 'tests/fixtures'],
};
```

`rulePacks` must export `{ rules, projectRules, languages }`. The runner builds the
language registry from the installed packs. Rules cannot be disabled from the config.

`runCheck({ root, configPath })` works without an explicit registry. A supplied
config object with `rulePacks` uses `root` as the resolver base.

## API migration

The TypeScript release removes the legacy `runSource` API. Parsing belongs to
language packs. Use `runCheck` for config-driven checks or `runProject` with a
language registry and split file/AST rules. `runProject` returns the report,
artifacts, and absolute files.

## Output

Human-readable by default. `--json` emits the versioned report v2 contract, including
`diagnostics`, `exceptions`, and `summary.count`. Exit code is `1` when diagnostics
exist, `2` for checker/config errors.

## No-bypass policy

The checker rejects:

- inline suppression directives such as `biome-ignore`, `eslint-disable`,
  `oxlint-disable`, `@ts-ignore`, `@ts-expect-error`, `prettier-ignore`
- lint rules set to `off` or `warn`
- ignore patterns that may exclude source files
- package scripts containing `|| true`, `--no-verify`, `--no-ignore`,
  `--quiet` or `--silent`

No inline exceptions. If a rule needs an exception, change the rule and add a test.
