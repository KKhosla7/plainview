---
name: dwarapal
description: Run Dwarapal after edits and fix stable diagnostics without suppressions.
---

# Dwarapal guidance

- Run Dwarapal after edits.
- Read the stable diagnostic ID.
- Fix the code.
- Never add a suppression.
- Never add an exception without approval.
