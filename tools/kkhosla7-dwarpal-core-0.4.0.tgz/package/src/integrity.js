import { createHash } from 'node:crypto';
import fs from 'node:fs/promises';
import path from 'node:path';

import { fileURLToPath } from 'node:url';

const PACKAGE_ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const HASHED_DIRECTORIES = ['src', 'bin'];
const HASHED_FILES = ['package.json'];

async function collect(directory) {
	const entries = await fs.readdir(directory, { withFileTypes: true });
	const files = [];
	for (const entry of entries) {
		const full = path.join(directory, entry.name);
		if (entry.isDirectory()) {
			files.push(...(await collect(full)));
		} else if (entry.isFile()) {
			files.push(full);
		}
	}
	return files;
}

async function hashFile(file) {
	const buffer = await fs.readFile(file);
	return createHash('sha256').update(buffer).digest('hex');
}

export async function buildIntegrity() {
	const files = [];
	for (const directory of HASHED_DIRECTORIES) {
		files.push(...(await collect(path.join(PACKAGE_ROOT, directory))));
	}
	for (const file of HASHED_FILES) {
		files.push(path.join(PACKAGE_ROOT, file));
	}

	const hashes = {};
	for (const file of files.sort()) {
		hashes[path.relative(PACKAGE_ROOT, file)] = await hashFile(file);
	}
	return hashes;
}

export async function verifyIntegrity() {
	const integrityFile = path.join(PACKAGE_ROOT, 'integrity.json');
	let expected;
	try {
		expected = JSON.parse(await fs.readFile(integrityFile, 'utf8'));
	} catch {
		throw new Error('dwarpal-core integrity.json is missing');
	}

	const actual = await buildIntegrity();
	const expectedKeys = Object.keys(expected).sort();
	const actualKeys = Object.keys(actual).sort();
	if (JSON.stringify(expectedKeys) !== JSON.stringify(actualKeys)) {
		throw new Error('dwarpal-core package file set does not match integrity.json');
	}

	for (const key of expectedKeys) {
		if (expected[key] !== actual[key]) {
			throw new Error(`dwarpal-core package file was modified: ${key}`);
		}
	}
}
