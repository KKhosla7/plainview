import fs from 'node:fs/promises';
import path from 'node:path';

function globToRegExp(pattern) {
	const escaped = pattern
		.replace(/[.+^${}()|[\]\\]/gu, '\\$&')
		.replace(/\*\*/gu, '\u0000')
		.replace(/\*/gu, '[^/]*')
		.replace(/\?/gu, '[^/]')
		.replace(/\u0000/gu, '.*');
	return new RegExp(`^${escaped}$`, 'u');
}

function isExcluded(relative, patterns) {
	for (const pattern of patterns) {
		if (pattern.includes('*')) {
			if (globToRegExp(pattern).test(relative)) {
				return true;
			}
			continue;
		}
		const parts = relative.split('/');
		if (parts.includes(pattern) || relative.startsWith(`${pattern}/`)) {
			return true;
		}
	}
	return false;
}

async function collectFrom(root, current, config, files) {
	const entries = await fs.readdir(current, { withFileTypes: true });

	for (const entry of entries) {
		const full = path.join(current, entry.name);
		const relative = path.relative(root, full).replaceAll(path.sep, '/');
		if (isExcluded(relative, config.exclude ?? [])) {
			continue;
		}
		if (entry.isDirectory()) {
			if (config.excludeDirectories.includes(entry.name)) {
				continue;
			}
			await collectFrom(root, full, config, files);
			continue;
		}

		if (entry.isFile() && config.includeExtensions.includes(path.extname(entry.name))) {
			files.push(full);
		}
	}
}

export async function collectFiles(root, config) {
	const files = [];
	for (const entry of config.include ?? ['.']) {
		const target = path.resolve(root, entry);
		let stat;
		try {
			stat = await fs.stat(target);
		} catch {
			continue;
		}
		if (stat.isDirectory()) {
			await collectFrom(root, target, config, files);
		} else if (stat.isFile()) {
			files.push(target);
		}
	}
	return files.sort();
}
