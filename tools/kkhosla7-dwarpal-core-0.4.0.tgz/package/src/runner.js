import fs from 'node:fs/promises';
import path from 'node:path';

import { DEFAULT_CONFIG, loadConfig } from './config.js';
import { loadConfigModule, loadRulePacks, validateConfig } from './config-loader.js';
import { createLanguageRegistry } from './language.js';
import { verifyIntegrity } from './integrity.js';
import { positionAt } from './position.js';
import { createReporter, sortDiagnostics } from './reporter.js';
import { walk } from './walk.js';
import { collectFiles } from './files.js';
import { detectLanguagePacks } from './language.js';
import { collectProjectFiles, readProjectFile } from './project-files.js';
import { parseSource } from './source.js';
import { attachLocations } from './locations.js';
function offsetOf(node, artifact) {
	if (typeof node?.start === 'number') {
		return artifact.offset + node.start;
	}

	if (typeof node?.source?.start?.offset === 'number') {
		return artifact.offset + node.source.start.offset;
	}

	return artifact.offset;
}

function collectComments(artifacts) {
	const comments = [];
	const seen = new Set();

	function add(comment) {
		const key = `${String(comment.start)}:${String(comment.end)}:${String(comment.value)}`;
		if (seen.has(key)) {
			return;
		}
		seen.add(key);
		comments.push(comment);
	}

	for (const artifact of artifacts) {
		if (artifact.language === 'css') {
			artifact.ast.walkComments((comment) => {
				const start = artifact.offset + (comment.source?.start?.offset ?? 0);
				add({ start, end: start, value: comment.text });
			});
			continue;
		}

		for (const comment of artifact.comments) {
			add({
				start: artifact.offset + (comment.start ?? 0),
				end: artifact.offset + (comment.end ?? 0),
				value: comment.value
			});
		}
	}

	return comments;
}

export function runSource({ source, filename = 'fixture.js', rules = [], root = '.' }) {
	const artifact = parseSource(filename, source);
	const reporter = createReporter(root);
	const state = { functionBodies: new Map() };

	for (const rule of rules) {
		if (typeof rule.create !== 'function') {
			continue;
		}

		const visitor =
			rule.create({
				root,
				file: filename,
				filename,
				relativeFile: filename,
				source,
				artifact,
				ast: artifact.ast,
				comments: artifact.comments,
				config: DEFAULT_CONFIG,
				state,
				walk(node, visit) {
					walk(node, visit);
				},
				lineAt(offset) {
					return positionAt(source, offset).line;
				},
				reportAt(offset, message) {
					reporter.report({
						file: filename,
						source,
						offset,
						ruleId: rule.id,
						message
					});
				},
				report(node, message) {
					reporter.report({
						file: filename,
						source,
						offset: offsetOf(node, artifact),
						ruleId: rule.id,
						message
					});
				}
			}) ?? {};

		walk(artifact.ast, (node, parent) => {
			const handler = visitor[node.type];
			if (typeof handler === 'function') {
				handler(node, parent);
			}
		});
	}

	return sortDiagnostics(reporter.diagnostics);
}

export async function runCheck({
	root,
	configPath,
	rules = [],
	projectRules = [],
	config,
	paths = [],
	registry,
	languages = []
}) {
	let activeConfig;
	let resolvedLanguages = languages;
	if (configPath) {
		activeConfig = await loadConfigModule(configPath);
		if (rules.length === 0 && projectRules.length === 0) {
			({ rules, projectRules, languages: resolvedLanguages } = await loadRulePacks(activeConfig, configPath));
		}
	} else if (config) {
		activeConfig = validateConfig({ ...DEFAULT_CONFIG, ...config });
		if (rules.length === 0 && projectRules.length === 0 && (activeConfig.rulePacks ?? []).length > 0) {
			({ rules, projectRules, languages: resolvedLanguages } = await loadRulePacks(
				activeConfig,
				path.join(root, 'config.js')
			));
		}
	} else {
		activeConfig = await loadConfig(root);
	}

	if (configPath && rules.length === 0 && projectRules.length === 0) {
		throw new Error('Configuration does not enable any rule packs');
	}

	const activeRegistry = registry ?? (resolvedLanguages.length > 0 ? createLanguageRegistry(resolvedLanguages) : null);
	if (!activeRegistry) {
		throw new Error('A registry or at least one language pack is required');
	}

	const effectiveConfig = paths.length > 0 ? { ...activeConfig, include: paths } : activeConfig;
	const files = await collectFiles(root, effectiveConfig);
	const diagnostics = await runProject({
		root,
		registry: activeRegistry,
		rules,
		projectRules,
		config: effectiveConfig
	});
	return { diagnostics, files };
}

export async function runProject({
	root,
	registry,
	rules = [],
	projectRules = [],
	config: suppliedConfig
}) {
	await verifyIntegrity();
	const config = suppliedConfig ?? (await loadConfig(root));
	const files = await collectFiles(root, config);
	detectLanguagePacks(registry, files);
	const reporter = createReporter(root);
	const state = { functionBodies: new Map() };

	for (const file of files) {
		const source = await fs.readFile(file, 'utf8');
		const extension = path.extname(file).toLowerCase();
		const packId = registry.byExtension.get(extension);
		const pack = packId ? registry.byId.get(packId) : null;
		const artifacts = pack ? await pack.parse(file, source) : [];
		for (const artifact of artifacts) {
			attachLocations(artifact.ast, source);
		}
		const relativeFile = path.relative(root, file);
		const comments = collectComments(artifacts);

		for (const rule of rules) {
			if (typeof rule.checkFile === 'function') {
				rule.checkFile({
					root,
					file,
					filename: file,
					relativeFile,
					source,
					comments,
					config,
					state,
					walk(node, visit) {
						walk(node, visit);
					},
					lineAt(offset) {
						return positionAt(source, offset).line;
					},
					reportAt(offset, message) {
						reporter.report({
							file,
							source,
							offset,
							ruleId: rule.id,
							message
						});
					}
				});
			}

			if (typeof rule.create !== 'function') {
				continue;
			}

			for (const artifact of artifacts) {
				if (rule.languages && !rule.languages.includes(artifact.language)) {
					continue;
				}

				if (rule.artifactKinds && !rule.artifactKinds.includes(artifact.kind)) {
					continue;
				}

				const visitor =
					rule.create({
						root,
						file,
						filename: file,
						relativeFile,
						source,
						artifact,
						ast: artifact.ast,
						comments: artifact.comments,
						config,
						state,
						walk(node, visit) {
							walk(node, visit);
						},
						lineAt(offset) {
							return positionAt(source, offset).line;
						},
						reportAt(offset, message) {
							reporter.report({
								file,
								source,
								offset,
								ruleId: rule.id,
								message
							});
						},
						report(node, message) {
							reporter.report({
								file,
								source,
								offset: offsetOf(node, artifact),
								ruleId: rule.id,
								message
							});
						}
					}) ?? {};

				walk(artifact.ast, (node, parent) => {
					const handler = visitor[node.type];
					if (typeof handler === 'function') {
						handler(node, parent);
					}
				});
			}
		}
	}

	const projectFiles = collectProjectFiles(root);
	for (const rule of projectRules) {
		if (typeof rule.check !== 'function') {
			continue;
		}

		await rule.check({
			files: projectFiles,
			readFile: readProjectFile,
			root,
			report(item) {
				reporter.report({
					file: path.resolve(root, item.file),
					line: item.line || 1,
					column: item.column || 1,
					ruleId: rule.id,
					message: item.message || rule.message
				});
			}
		});
	}

	return sortDiagnostics(reporter.diagnostics);
}
