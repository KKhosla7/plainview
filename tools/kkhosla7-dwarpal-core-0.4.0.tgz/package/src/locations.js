import { walk } from './walk.js';

function lineStarts(source) {
	const starts = [0];
	for (let index = 0; index < source.length; index += 1) {
		if (source[index] === '\n') {
			starts.push(index + 1);
		}
	}
	return starts;
}

function locationOf(starts, offset) {
	let low = 0;
	let high = starts.length - 1;
	while (low < high) {
		const middle = Math.ceil((low + high) / 2);
		if (starts[middle] <= offset) {
			low = middle;
		} else {
			high = middle - 1;
		}
	}
	return { line: low + 1, column: offset - starts[low] };
}

export function attachLocations(ast, source) {
	const starts = lineStarts(source);
	walk(ast, (node) => {
		if (node.loc || typeof node.start !== 'number' || typeof node.end !== 'number') {
			return;
		}
		node.loc = {
			start: locationOf(starts, node.start),
			end: locationOf(starts, node.end)
		};
	});
	return ast;
}
