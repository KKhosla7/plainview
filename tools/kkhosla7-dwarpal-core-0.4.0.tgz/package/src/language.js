function isRecord(value) {
	return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function normalizeExtension(extension) {
	if (typeof extension !== 'string' || !extension.startsWith('.')) {
		throw new TypeError(`Invalid extension: ${String(extension)}`);
	}
	return extension.toLowerCase();
}

export function defineLanguagePack(candidate) {
	if (!isRecord(candidate)) {
		throw new TypeError('Language pack must be an object');
	}

	const { id, extensions, implies = [], capabilities = {}, parse } = candidate;

	if (typeof id !== 'string' || !/^[a-z][a-z0-9-]*$/u.test(id)) {
		throw new TypeError(`Invalid language pack id: ${String(id)}`);
	}

	if (!Array.isArray(extensions) || extensions.length === 0) {
		throw new TypeError(`Language pack ${id} must declare extensions`);
	}

	if (!Array.isArray(implies)) {
		throw new TypeError(`Language pack ${id} implies must be an array`);
	}

	if (typeof parse !== 'function') {
		throw new TypeError(`Language pack ${id} must provide parse()`);
	}

	const normalizedExtensions = [...new Set(extensions.map(normalizeExtension))];
	const normalizedImplies = [...new Set(implies)];

	for (const implied of normalizedImplies) {
		if (typeof implied !== 'string' || !/^[a-z][a-z0-9-]*$/u.test(implied)) {
			throw new TypeError(`Language pack ${id} has an invalid implied pack: ${String(implied)}`);
		}
	}

	return Object.freeze({
		id,
		extensions: Object.freeze(normalizedExtensions),
		implies: Object.freeze(normalizedImplies),
		capabilities: Object.freeze({ ...capabilities }),
		parse
	});
}

export function createLanguageRegistry(packs) {
	if (!Array.isArray(packs) || packs.length === 0) {
		throw new TypeError('Language registry requires at least one pack');
	}

	const byId = new Map();
	const byExtension = new Map();

	for (const pack of packs) {
		if (byId.has(pack.id)) {
			throw new TypeError(`Duplicate language pack id: ${pack.id}`);
		}
		byId.set(pack.id, pack);

		for (const extension of pack.extensions) {
			const owner = byExtension.get(extension);
			if (owner && owner !== pack.id) {
				throw new TypeError(`Extension ${extension} is claimed by ${owner} and ${pack.id}`);
			}
			byExtension.set(extension, pack.id);
		}
	}

	for (const pack of packs) {
		for (const implied of pack.implies) {
			if (!byId.has(implied)) {
				throw new TypeError(`Language pack ${pack.id} implies missing pack ${implied}`);
			}
		}
	}

	return Object.freeze({ packs: Object.freeze([...packs]), byId, byExtension });
}

export function detectLanguagePacks(registry, files) {
	if (!Array.isArray(files)) {
		throw new TypeError('Files must be an array');
	}

	const detected = new Set();
	const visiting = new Set();

	function include(id) {
		if (detected.has(id)) {
			return;
		}
		if (visiting.has(id)) {
			throw new TypeError(`Cyclic language pack implication at ${id}`);
		}

		const pack = registry.byId.get(id);
		if (!pack) {
			throw new TypeError(`Unknown language pack: ${id}`);
		}

		visiting.add(id);
		detected.add(id);
		for (const implied of pack.implies) {
			include(implied);
		}
		visiting.delete(id);
	}

	for (const file of files) {
		const dot = file.lastIndexOf('.');
		if (dot === -1) {
			continue;
		}
		const extension = file.slice(dot).toLowerCase();
		const id = registry.byExtension.get(extension);
		if (id) {
			include(id);
		}
	}

	if (detected.size === 0) {
		throw new Error('No language packs detected');
	}

	return Object.freeze([...detected].sort().map((id) => registry.byId.get(id)));
}
