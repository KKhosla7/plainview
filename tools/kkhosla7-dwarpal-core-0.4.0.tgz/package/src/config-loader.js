import path from 'node:path';
import { createRequire } from 'node:module';
import { pathToFileURL } from 'node:url';

import { DEFAULT_CONFIG } from './config.js';

const ALLOWED_KEYS = new Set([
	'rulePacks',
	'include',
	'exclude',
	'maxFileLines',
	'maxFunctionLines',
	'maxParams',
	'maxComplexity',
	'maxDuplicateFunctionLines',
	'excludeDirectories',
	'includeExtensions'
]);

const PACKAGE_SPECIFIER = /^(?:@[a-z0-9][a-z0-9._-]*\/)?[a-z0-9][a-z0-9._-]*$/iu;

export function validateConfig(config) {
	if (!config || typeof config !== 'object' || Array.isArray(config)) {
		throw new TypeError('Configuration must be an object');
	}

	for (const key of Object.keys(config)) {
		if (!ALLOWED_KEYS.has(key)) {
			throw new TypeError(`Configuration cannot override rule behavior with "${key}"`);
		}
	}

	if (config.rulePacks !== undefined) {
		if (!Array.isArray(config.rulePacks)) {
			throw new TypeError('rulePacks must be an array');
		}

		for (const specifier of config.rulePacks) {
			if (typeof specifier !== 'string' || !PACKAGE_SPECIFIER.test(specifier)) {
				throw new TypeError(
					`rulePacks must reference installed packages, not paths: ${String(specifier)}`
				);
			}
		}
	}

	return config;
}

export async function loadConfigModule(configPath) {
	const absolute = path.resolve(configPath);
	const module = await import(pathToFileURL(absolute).href);
	return validateConfig({ ...DEFAULT_CONFIG, ...(module.default ?? {}) });
}

export async function loadRulePacks(config, configPath) {
	const rules = [];
	const projectRules = [];
	const languages = [];
	const resolver = createRequire(configPath ? path.resolve(configPath) : path.join(process.cwd(), 'config.js'));

	for (const specifier of config.rulePacks ?? []) {
		let resolved;
		try {
			resolved = resolver.resolve(specifier);
		} catch {
			throw new Error(`Rule pack is not installed: ${specifier}`);
		}

		const pack = await import(pathToFileURL(resolved).href);
		const value = pack.default ?? pack;
		rules.push(...(value.rules ?? []));
		projectRules.push(...(value.projectRules ?? []));
		languages.push(...(value.languages ?? []));
	}

	return { rules, projectRules, languages };
}
