import fs from 'node:fs';
import path from 'node:path';

const PROJECT_CONFIG_NAMES = [
	'.eslintrc',
	'.eslintrc.json',
	'.oxlintrc.json',
	'biome.json',
	'biome.jsonc',
	'eslint.config.cjs',
	'eslint.config.js',
	'eslint.config.js',
	'eslint.config.ts',
	'oxlint.config.cjs',
	'oxlint.config.js',
	'oxlint.config.js',
	'oxlint.config.ts',
	'package.json'
];

export function collectProjectFiles(root) {
	const files = [];
	for (const name of PROJECT_CONFIG_NAMES) {
		const file = path.join(root, name);
		if (fs.existsSync(file)) {
			files.push(file);
		}
	}
	return files;
}

export function readProjectFile(file) {
	try {
		return fs.readFileSync(file, 'utf8');
	} catch {
		return null;
	}
}
