import fs from 'node:fs/promises';
import path from 'node:path';

export const DEFAULT_CONFIG = Object.freeze({
	maxFileLines: 300,
	maxFunctionLines: 50,
	maxParams: 5,
	maxComplexity: 20,
	maxDuplicateFunctionLines: 12,
	excludeDirectories: [
		'node_modules',
		'.git',
		'.svelte-kit',
		'build',
		'dist',
		'coverage',
		'playwright-report',
		'test-results'
	],
	includeExtensions: ['.js', '.jsx', '.mjs', '.cjs', '.ts', '.tsx', '.svelte', '.css'],
	include: ['.'],
	exclude: ['node_modules', '.git', '.svelte-kit', 'build', 'dist', 'coverage', 'playwright-report', 'test-results']
});

const ALLOWED_KEYS = new Set([
	'maxFileLines',
	'maxFunctionLines',
	'maxParams',
	'maxComplexity',
	'maxDuplicateFunctionLines',
	'excludeDirectories',
	'includeExtensions'
]);

export async function loadConfig(root) {
	const file = path.join(root, 'dwarpal.config.json');
	let local = {};

	try {
		local = JSON.parse(await fs.readFile(file, 'utf8'));
	} catch (error) {
		if (error.code !== 'ENOENT') {
			throw error;
		}
	}

	for (const key of Object.keys(local)) {
		if (!ALLOWED_KEYS.has(key)) {
			throw new Error(`dwarpal.config.json cannot override rule behavior with "${key}"`);
		}
	}

	return { ...DEFAULT_CONFIG, ...local };
}
