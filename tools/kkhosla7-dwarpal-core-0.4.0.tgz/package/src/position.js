export function positionAt(source, offset) {
	const safeOffset = Math.max(0, Math.min(source.length, offset));
	const before = source.slice(0, safeOffset);
	const line = before.split('\n').length;
	const lastBreak = before.lastIndexOf('\n');
	const column = safeOffset - lastBreak;
	return { line, column };
}

export function lineCount(source) {
	return source.split('\n').length;
}
