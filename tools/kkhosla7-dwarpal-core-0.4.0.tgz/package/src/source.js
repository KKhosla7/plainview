import path from 'node:path';

import { parseSync } from 'oxc-parser';

import { createArtifact } from './artifact.js';
import { attachLocations } from './locations.js';

const LANGUAGES = new Map([
	['.js', 'js'],
	['.jsx', 'js'],
	['.mjs', 'js'],
	['.cjs', 'js'],
	['.ts', 'ts'],
	['.tsx', 'ts']
]);

export function parseSource(filename, source) {
	const extension = path.extname(filename).toLowerCase();
	const language = LANGUAGES.get(extension) ?? 'js';
	const parsed = parseSync(filename, source, {
		sourceType: 'module',
		lang: language === 'ts' ? 'ts' : 'js',
		preserveParens: false
	});

	return createArtifact({
		language: 'js',
		kind: 'script',
		file: filename,
		source,
		ast: attachLocations(parsed.program, source),
		comments: parsed.comments ?? []
	});
}
