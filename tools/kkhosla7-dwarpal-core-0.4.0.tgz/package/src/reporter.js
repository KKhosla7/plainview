import path from 'node:path';

import { positionAt } from './position.js';

export function createReporter(root) {
	const diagnostics = [];

	return {
		diagnostics,
		report({ file, source, offset, line, column, ruleId, message }) {
			const location =
				source != null && offset != null
					? positionAt(source, offset)
					: { line: line ?? 1, column: column ?? 1 };
			diagnostics.push({
				file: path.relative(root, file),
				line: location.line,
				column: location.column,
				ruleId,
				rule: ruleId,
				message
			});
		}
	};
}

export function sortDiagnostics(diagnostics) {
	return diagnostics.toSorted((left, right) => {
		const fileOrder = left.file.localeCompare(right.file);
		if (fileOrder !== 0) return fileOrder;
		const lineOrder = left.line - right.line;
		if (lineOrder !== 0) return lineOrder;
		return left.column - right.column;
	});
}

export function formatHuman(diagnostics) {
	if (diagnostics.length === 0) return 'No diagnostics.';
	const lines = diagnostics.map(
		(item) => `${item.file}:${item.line}:${item.column}  error  ${item.rule}  ${item.message}`
	);
	lines.push('');
	lines.push(`${diagnostics.length} diagnostic${diagnostics.length === 1 ? '' : 's'}.`);
	return lines.join('\n');
}

export function formatJson(diagnostics) {
	return JSON.stringify(
		{ diagnostics, summary: { count: diagnostics.length } },
		null,
		2
	);
}
