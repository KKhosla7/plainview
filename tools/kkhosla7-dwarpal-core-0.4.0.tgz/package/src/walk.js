const SKIP_KEYS = new Set(['parent', 'loc', 'comments', 'leadingComments', 'trailingComments', 'tokens']);

export function walk(node, visit, parent = null) {
	if (!node || typeof node !== 'object') {
		return;
	}

	if (Array.isArray(node)) {
		for (const child of node) {
			walk(child, visit, parent);
		}

		return;
	}

	if (typeof node.type === 'string') {
		visit(node, parent);
	}

	for (const [key, value] of Object.entries(node)) {
		if (SKIP_KEYS.has(key) || value === null || typeof value !== 'object') {
			continue;
		}

		walk(value, visit, node);
	}
}
