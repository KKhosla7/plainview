export const ARTIFACT_SCHEMA_VERSION = 1;

export const ARTIFACT_KINDS = Object.freeze([
	'script',
	'template',
	'style',
	'document',
	'resource'
]);

function isRecord(value) {
	return typeof value === 'object' && value !== null && !Array.isArray(value);
}

export function createArtifact(candidate) {
	if (!isRecord(candidate)) {
		throw new TypeError('Artifact must be an object');
	}

	const { language, kind, file, source, offset = 0, ast, comments = [] } = candidate;

	if (typeof language !== 'string' || language.length === 0) {
		throw new TypeError('Artifact language must be a non-empty string');
	}

	if (!ARTIFACT_KINDS.includes(kind)) {
		throw new TypeError(`Unknown artifact kind: ${String(kind)}`);
	}

	if (typeof file !== 'string' || file.length === 0) {
		throw new TypeError('Artifact file must be a non-empty string');
	}

	if (typeof source !== 'string') {
		throw new TypeError('Artifact source must be a string');
	}

	if (!Number.isInteger(offset) || offset < 0) {
		throw new TypeError('Artifact offset must be a non-negative integer');
	}

	if (!Array.isArray(comments)) {
		throw new TypeError('Artifact comments must be an array');
	}

	return Object.freeze({
		schemaVersion: ARTIFACT_SCHEMA_VERSION,
		language,
		kind,
		file,
		source,
		offset,
		ast,
		comments: Object.freeze(comments)
	});
}
