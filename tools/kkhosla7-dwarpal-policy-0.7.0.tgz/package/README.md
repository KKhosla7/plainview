# dwarapal-policy

Shared policy rules that apply across language packs. Rules are implemented once
here and composed by presets such as `@kkhosla7/dwarpal-svelte`.
