# Rule backlog

The five candidates from the first Plainview cleanup are implemented and tested:

- `no-swallowed-promise`
- `no-magic-capacity`
- `no-inline-setting-key`
- `require-sanitized-markup`
- `require-timer-cleanup`

## Next candidate

### no-floating-promise

Detect promises that are started but neither awaited, returned, nor routed to a
named error handler. `no-unhandled-async-listener` only covers event listeners;
general detached promises are still invisible.

Do not add this until the current Plainview cleanup batch is finished.
