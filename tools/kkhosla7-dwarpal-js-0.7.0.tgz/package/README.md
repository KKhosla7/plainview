# dwarpal-js

JavaScript, JSX, and TypeScript parser and rules for `@kkhosla7/dwarpal-core`.

The package is published privately to GitHub Packages as `@kkhosla7/dwarpal-js`.
It declares its parser through the `languages` export.

## Install

```bash
npm install --save-dev @kkhosla7/dwarpal-js
```

Configure the scope once:

```ini
# .npmrc
@kkhosla7:registry=https://npm.pkg.github.com
```

Set `NODE_AUTH_TOKEN` to a GitHub token with `read:packages` for private installs.

## Rules

Security and boundaries:

- `no-direct-network`
- `no-remote-url`
- `no-javascript-url`
- `no-eval`
- `no-unsafe-embed`
- `no-unsafe-dynamic-import`
- `no-prototype-pollution`
- `no-cookie-access`
- `no-insecure-random`
- `no-inline-html`
- `no-embedded-document`
- `require-sanitized-markup`

Correctness and async:

- `no-swallowed-error`
- `no-swallowed-promise`
- `no-unhandled-async-listener`
- `no-async-array-callback`
- `no-for-in-without-own`
- `require-timer-cleanup`

DOM and browser APIs:

- `no-deprecated-dom-api`
- `no-inline-setting-key`
- `no-magic-timing`
- `no-magic-capacity`

Code shape:

- `no-array-filter-map`
- `no-reduce-accumulator-copy`
- `no-conditional-empty-object-spread`
- `no-module-mocking`
- `no-reflect`
- `no-shape-in-symbol-names`
- `no-unbounded-typeof`
- `no-todo-comments`
- `no-suppression-directive`
- `require-readable-spacing`

God limits:

- `max-file-lines`
- `max-function-lines`
- `max-block-lines`
- `max-params`
- `max-nesting-depth`
- `max-statements-per-block`

Project checks:

- `no-config-weakening`

## Policy

Inline suppression directives are not allowed. The rule pack also rejects lint-rule
downgrades, broad source ignores and scripts that swallow check failures.

There is no configuration switch to turn a rule off. Add or change rules in source,
with tests, instead of bypassing them.

## Rule API

```js
export default {
  id: 'rule-id',
  message: 'What is wrong.',
  create(context) {
    return {
      CallExpression(node) {
        context.report(node, 'A more specific message.');
      },
    };
  },
};
```

Context provides `source`, `filename`, `comments`, `root`, `walk()` and `report()`.

- `no-embedded-document` — reject doctype, html, head, body, script, and style markup embedded in JavaScript strings.
