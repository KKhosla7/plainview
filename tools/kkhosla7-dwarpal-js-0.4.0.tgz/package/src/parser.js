import path from 'node:path';

import { parseSync } from 'oxc-parser';

const LANGUAGES = new Map([
	['.js', 'js'],
	['.jsx', 'js'],
	['.mjs', 'js'],
	['.cjs', 'js'],
	['.ts', 'ts'],
	['.tsx', 'ts']
]);

export function parseJavaScript(file, source, offset = 0) {
	const extension = path.extname(file).toLowerCase();
	const language = LANGUAGES.get(extension) ?? 'js';
	const parsed = parseSync(file, source, {
		sourceType: 'module',
		lang: language === 'ts' ? 'ts' : 'js',
		preserveParens: false
	});

	return [
		Object.freeze({
			schemaVersion: 1,
			language: 'js',
			kind: 'script',
			file,
			source,
			offset,
			ast: parsed.program,
			comments: Object.freeze(parsed.comments ?? [])
		})
	];
}
