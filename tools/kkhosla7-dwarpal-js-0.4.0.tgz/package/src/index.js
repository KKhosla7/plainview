import noCookieAccess from './rules/no-cookie-access.js';
import noDirectNetwork from './rules/no-direct-network.js';
import noPrototypePollution from './rules/no-prototype-pollution.js';
import noUnhandledAsyncListener from './rules/no-unhandled-async-listener.js';
import noUnsafeDynamicImport from './rules/no-unsafe-dynamic-import.js';
import noUnsafeEmbed from './rules/no-unsafe-embed.js';
import noAsyncArrayCallback from './rules/no-async-array-callback.js';
import noDeprecatedDomApi from './rules/no-deprecated-dom-api.js';
import noEval from './rules/no-eval.js';
import noForInWithoutOwn from './rules/no-for-in-without-own.js';
import noInsecureRandom from './rules/no-insecure-random.js';
import noEmbeddedDocument from './rules/no-embedded-document.js';
import noInlineHtml from './rules/no-inline-html.js';
import noJavascriptUrl from './rules/no-javascript-url.js';
import noMagicTiming from './rules/no-magic-timing.js';
import noRemoteUrl from './rules/no-remote-url.js';
import noSwallowedError from './rules/no-swallowed-error.js';
import noTodoComments from './rules/no-todo-comments.js';
import maxBlockLines from './rules/max-block-lines.js';
import maxFileLines from './rules/max-file-lines.js';
import maxFunctionLines from './rules/max-function-lines.js';
import maxNestingDepth from './rules/max-nesting-depth.js';
import maxParams from './rules/max-params.js';
import maxStatementsPerBlock from './rules/max-statements-per-block.js';
import noArrayFilterMap from './rules/no-array-filter-map.js';
import noConditionalEmptyObjectSpread from './rules/no-conditional-empty-object-spread.js';
import noConfigWeakening from './project-rules/no-config-weakening.js';
import noModuleMocking from './rules/no-module-mocking.js';
import noReduceAccumulatorCopy from './rules/no-reduce-accumulator-copy.js';
import noReflect from './rules/no-reflect.js';
import noShapeInSymbolNames from './rules/no-shape-in-symbol-names.js';
import noSuppressionDirective from './rules/no-suppression-directive.js';
import noUnboundedTypeof from './rules/no-unbounded-typeof.js';
import noMagicCapacity from './rules/no-magic-capacity.js';
import noInlineSettingKey from './rules/no-inline-setting-key.js';
import noSwallowedPromise from './rules/no-swallowed-promise.js';
import requireSanitizedMarkup from './rules/require-sanitized-markup.js';
import requireTimerCleanup from './rules/require-timer-cleanup.js';
import requireReadableSpacing from './rules/require-readable-spacing.js';
import { languages } from './pack.js';

const rules = [
  maxFileLines,
  maxFunctionLines,
  maxBlockLines,
  maxParams,
  maxNestingDepth,
  maxStatementsPerBlock,
  noDirectNetwork,
  noPrototypePollution,
  noUnsafeEmbed,
  noUnsafeDynamicImport,
  noCookieAccess,
  noUnhandledAsyncListener,
  noAsyncArrayCallback,
  noDeprecatedDomApi,
  noEval,
  noForInWithoutOwn,
  noInsecureRandom,
  noEmbeddedDocument,
  noInlineHtml,
  noJavascriptUrl,
  noMagicTiming,
  noRemoteUrl,
  noSwallowedError,
  noTodoComments,
  noArrayFilterMap,
  noReduceAccumulatorCopy,
  noConditionalEmptyObjectSpread,
  noModuleMocking,
  noReflect,
  noShapeInSymbolNames,
  noUnboundedTypeof,
  noSuppressionDirective,
  noSwallowedPromise,
  noMagicCapacity,
  noInlineSettingKey,
  requireSanitizedMarkup,
  requireTimerCleanup,
  requireReadableSpacing,
];

const projectRules = [noConfigWeakening];

export { projectRules, rules, languages };
export { languagePack } from './pack.js';
export default { projectRules, rules, languages };
