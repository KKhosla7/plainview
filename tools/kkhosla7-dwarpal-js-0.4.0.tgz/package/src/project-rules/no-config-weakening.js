const BypassScript =
  /(\|\|\s*true|--no-verify|--no-ignore|--quiet|--silent|eslint-disable|biome-ignore)/iu;
const Suppression =
  /(biome-ignore|eslint-disable|oxlint-disable|@ts-ignore|@ts-expect-error|@ts-nocheck|prettier-ignore|noqa|istanbul\s+ignore|c8\s+ignore|v8\s+ignore)/iu;
const WeakRule = /(["']?(?:off|warn)["']?\s*[,}])/u;
const IgnoreSource = /(src|tests?|scripts?|\*\*\/\*|\*)/iu;

function lineOf(text, index) {
  return text.slice(0, index).split('\n').length;
}

function scanScripts(text, report, file) {
  let config;
  try {
    config = JSON.parse(text);
  } catch {
    return;
  }

  for (const [name, script] of Object.entries(config.scripts || {})) {
    if (BypassScript.test(String(script))) {
      const index = text.indexOf(`"${name}"`);
      report({
        file,
        line: lineOf(text, index === -1 ? 0 : index),
        column: 1,
        message: `Script "${name}" contains a check-bypass pattern.`,
      });
    }
  }
}

function scanConfig(text, report, file) {
  for (const [index, line] of text.split('\n').entries()) {
    if (Suppression.test(line)) {
      report({
        file,
        line: index + 1,
        column: 1,
        message: 'Suppression directive found in lint configuration.',
      });
    }

    if (WeakRule.test(line)) {
      report({
        file,
        line: index + 1,
        column: 1,
        message: 'Lint rule is disabled or downgraded to warning.',
      });
    }

    if (/ignorePatterns|ignores/iu.test(line) && IgnoreSource.test(line)) {
      report({
        file,
        line: index + 1,
        column: 1,
        message: 'Ignore pattern may exclude source files from checks.',
      });
    }
  }
}

const rule = {
  id: 'no-config-weakening',
  message: 'Lint configuration or scripts weaken or bypass checks.',
  check({ files, readFile, report }) {
    for (const file of files) {
      const lower = file.toLocaleLowerCase();
      if (lower.endsWith('package.json')) {
        scanScripts(readFile(file), report, file);
        continue;
      }

      if (
        lower.endsWith('biome.json') ||
        lower.endsWith('biome.jsonc') ||
        lower.endsWith('.oxlintrc.json') ||
        lower.endsWith('.eslintrc') ||
        lower.endsWith('.eslintrc.json') ||
        /(?:oxlint|eslint)\.config\.[cm]?[jt]s$/u.test(lower)
      ) {
        scanConfig(readFile(file), report, file);
      }
    }
  },
};

export default rule;
