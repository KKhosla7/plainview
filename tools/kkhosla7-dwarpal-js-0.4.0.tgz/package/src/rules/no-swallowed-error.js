function isConsoleCall(statement) {
  return (
    statement.type === 'ExpressionStatement' &&
    statement.expression.type === 'CallExpression' &&
    statement.expression.callee.type === 'MemberExpression' &&
    !statement.expression.callee.computed &&
    statement.expression.callee.object.type === 'Identifier' &&
    statement.expression.callee.object.name === 'console'
  );
}

const rule = {
  id: 'no-swallowed-error',
  message:
    'Do not swallow errors. Recover deliberately, rethrow with context, or return a domain error.',
  create(context) {
    return {
      CatchClause(node) {
        if (node.body.body.length === 0) {
          context.report(
            node,
            'Empty catch block. Recover deliberately, rethrow with context, or return a domain error.',
          );
          return;
        }

        if (node.body.body.every(isConsoleCall)) {
          context.report(
            node,
            'Catch only logs the error. Recover deliberately, rethrow with context, or return a domain error.',
          );
        }
      },
      ThrowStatement(node) {
        if (node.argument?.type !== 'Literal') {
          return;
        }
        context.report(node, 'Throw an Error object with context, not a string or literal.');
      },
    };
  },
};

export default rule;
