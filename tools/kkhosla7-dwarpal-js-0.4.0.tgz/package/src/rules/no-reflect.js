const ReflectMethods = new Set(['apply', 'get']);

const rule = {
  id: 'no-reflect',
  message: 'Use typed property access or a typed function call instead of Reflect.apply/get.',
  create(context) {
    return {
      CallExpression(node) {
        const callee = node.callee;
        if (callee?.type !== 'MemberExpression') {
          return;
        }
        let method = '';
        if (!callee.computed && callee.property.type === 'Identifier') {
          method = callee.property.name;
        } else if (callee.computed && callee.property.type === 'Literal') {
          method = String(callee.property.value);
        }

        if (
          callee.object.type === 'Identifier' &&
          callee.object.name === 'Reflect' &&
          ReflectMethods.has(method)
        ) {
          context.report(node, rule.message);
        }
      },
    };
  },
};

export default rule;
