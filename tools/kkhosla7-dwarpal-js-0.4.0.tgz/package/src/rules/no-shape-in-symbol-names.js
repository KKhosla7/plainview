function isDeclaredIdentifier(node, parent) {
  if (!parent) {
    return false;
  }

  if (parent.type === 'VariableDeclarator' && parent.id === node) {
    return true;
  }

  if (
    (parent.type === 'FunctionDeclaration' ||
      parent.type === 'FunctionExpression' ||
      parent.type === 'ArrowFunctionExpression') &&
    parent.params?.includes(node)
  ) {
    return true;
  }

  if (
    (parent.type === 'FunctionDeclaration' || parent.type === 'ClassDeclaration') &&
    parent.id === node
  ) {
    return true;
  }

  return parent.type === 'PropertyDefinition' && parent.key === node;
}

const rule = {
  id: 'no-shape-in-symbol-names',
  message: 'Do not name locally owned symbols with the word shape.',
  create(context) {
    return {
      Identifier(node, parent) {
        if (!/shape/iu.test(node.name)) {
          return;
        }

        if (isDeclaredIdentifier(node, parent)) {
          context.report(node, rule.message);
        }
      },
    };
  },
};

export default rule;
