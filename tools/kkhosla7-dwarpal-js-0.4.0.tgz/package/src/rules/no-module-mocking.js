const MockingNames = new Set(['vi', 'jest']);
const MockingMethods = new Set(['mock', 'doMock', 'unstable_mockModule']);

const rule = {
  id: 'no-module-mocking',
  message: 'Do not mock modules; use real dependency seams instead.',
  create(context) {
    return {
      CallExpression(node) {
        const callee = node.callee;
        if (callee?.type !== 'MemberExpression' || callee.computed) {
          return;
        }

        if (callee.object.type !== 'Identifier' || callee.property.type !== 'Identifier') {
          return;
        }

        if (
          MockingNames.has(callee.object.name) &&
          MockingMethods.has(callee.property.name)
        ) {
          context.report(node, rule.message);
        }
      },
    };
  },
};

export default rule;
