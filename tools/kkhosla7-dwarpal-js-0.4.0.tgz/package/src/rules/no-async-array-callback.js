const ArrayMethods = new Set([
  'every',
  'filter',
  'find',
  'findIndex',
  'flatMap',
  'forEach',
  'map',
  'reduce',
  'reduceRight',
  'some',
]);

function memberName(member) {
  if (member?.type !== 'MemberExpression' || member.computed) {
    return '';
  }

  return member.property.type === 'Identifier' ? member.property.name : '';
}

const rule = {
  id: 'no-async-array-callback',
  message:
    'Do not pass async functions to array iteration methods. Use for...of with await, or Promise.all over mapped promises.',
  create(context) {
    return {
      CallExpression(node) {
        const method = memberName(node.callee);
        if (!ArrayMethods.has(method)) {
          return;
        }
        const callback = node.arguments[0];
        if (!callback || !callback.async) {
          return;
        }
        const replacement =
          method === 'map'
            ? 'Promise.all(items.map(async (item) => ...))'
            : 'for...of with await';
        context.report(
          node,
          `Do not pass an async callback to ${method}(). Use ${replacement}.`,
        );
      },
    };
  },
};

export default rule;
