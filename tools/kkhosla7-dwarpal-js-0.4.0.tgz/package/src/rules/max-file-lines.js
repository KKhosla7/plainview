const MaxLines = 300;

const rule = {
  id: 'max-file-lines',
  message: `Files must stay at or below ${MaxLines} lines.`,
  create(context) {
    return {
      Program(node) {
        const lines = context.source.split('\n').length;
        if (lines > MaxLines) {
          context.report(node, `File has ${lines} lines; maximum is ${MaxLines}.`);
        }
      },
    };
  },
};

export default rule;
