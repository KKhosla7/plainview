const Marker = /\b(?:TODO|FIXME|HACK|XXX)\b/u;

const rule = {
  id: 'no-todo-comments',
  message:
    'Do not ship TODO/FIXME/HACK/XXX markers. Create a tracked task and implement or delete the placeholder.',
  create(context) {
    return {
      Program() {
        for (const comment of context.comments || []) {
          if (Marker.test(comment.value)) {
            context.report(
              { loc: comment.loc },
              'Remove this TODO/FIXME/HACK/XXX marker; implement the work or link a tracked task.',
            );
          }
        }
      },
    };
  },
};

export default rule;
