function loopVariable(statement) {
  const left = statement.left;
  if (left.type === 'VariableDeclaration' && left.declarations[0]?.id.type === 'Identifier') {
    return left.declarations[0].id.name;
  }

  return left.type === 'Identifier' ? left.name : '';
}

function hasOwnGuard(statement, name, context) {
  let found = false;
  context.walk(statement.body, (node) => {
    if (
      node.type === 'CallExpression' &&
      node.callee.type === 'MemberExpression' &&
      !node.callee.computed &&
      node.callee.object.type === 'Identifier' &&
      node.callee.object.name === 'Object' &&
      node.callee.property.type === 'Identifier' &&
      node.callee.property.name === 'hasOwn' &&
      node.arguments[1]?.type === 'Identifier' &&
      node.arguments[1].name === name
    ) {
      found = true;
    }
  });
  return found;
}

const rule = {
  id: 'no-for-in-without-own',
  message:
    'Do not use for...in without an own-property guard. Use Object.keys/entries or Object.hasOwn.',
  create(context) {
    return {
      ForInStatement(node) {
        const name = loopVariable(node);
        if (name && hasOwnGuard(node, name, context)) {
          return;
        }
        context.report(
          node,
          'Replace for...in with Object.keys/Object.entries, or add an Object.hasOwn guard.',
        );
      },
    };
  },
};

export default rule;
