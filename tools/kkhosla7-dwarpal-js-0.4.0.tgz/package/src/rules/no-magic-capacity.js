const MinimumCapacity = 1000;
const CapacityCalls = new Set([
  'Array',
  'at',
  'padEnd',
  'padStart',
  'repeat',
  'slice',
  'splice',
  'subarray',
  'substring',
]);
const Comparisons = new Set(['<', '<=', '>', '>=']);

function memberName(member) {
  if (member?.type !== 'MemberExpression' || member.computed) {
    return '';
  }

  return member.property.type === 'Identifier' ? member.property.name : '';
}

function callName(callee) {
  return callee?.type === 'Identifier' ? callee.name : memberName(callee);
}

function isCapacityArgument(node, parent) {
  if (parent?.type !== 'CallExpression' && parent?.type !== 'NewExpression') {
    return false;
  }

  return CapacityCalls.has(callName(parent.callee)) && parent.arguments.includes(node);
}

function isCapacityComparison(node, parent) {
  return (
    parent?.type === 'BinaryExpression' &&
    Comparisons.has(parent.operator) &&
    (parent.left === node || parent.right === node)
  );
}

const rule = {
  id: 'no-magic-capacity',
  message: 'Do not inline large capacity limits. Use a named capacity constant.',
  create(context) {
    return {
      Literal(node, parent) {
        if (!Number.isFinite(node.value) || node.value < MinimumCapacity) {
          return;
        }

        if (parent?.type === 'VariableDeclarator' && parent.init === node) {
          return;
        }

        if (parent?.type === 'Property') {
          return;
        }

        if (!(isCapacityArgument(node, parent) || isCapacityComparison(node, parent))) {
          return;
        }
        context.report(
          node,
          `Replace the inline limit ${node.value} with a named capacity constant.`,
        );
      },
      ReturnStatement(node) {
        const value = node.argument;
        if (value?.type === 'Literal' && Number.isFinite(value.value) && value.value >= MinimumCapacity) {
          context.report(
            value,
            `Replace the inline limit ${value.value} with a named capacity constant.`,
          );
        }
      },
    };
  },
};

export default rule;
