function isEmptyHandler(handler) {
  if (handler?.type === 'ArrowFunctionExpression') {
    if (handler.body.type === 'BlockStatement') {
      return handler.body.body.length === 0;
    }

    return handler.body.type === 'Identifier' && handler.body.name === 'undefined';
  }

  if (handler?.type === 'FunctionExpression') {
    return handler.body.body.length === 0;
  }

  return false;
}

const rule = {
  id: 'no-swallowed-promise',
  message: 'Do not discard promise rejections with an empty or undefined rejection handler.',
  create(context) {
    return {
      CallExpression(node) {
        const callee = node.callee;
        if (
          callee.type !== 'MemberExpression' ||
          callee.computed ||
          callee.property.type !== 'Identifier' ||
          callee.property.name !== 'catch'
        ) {
          return;
        }

        if (isEmptyHandler(node.arguments[0])) {
          context.report(
            node,
            'Use a named recovery handler that returns a domain result or rethrows with context.',
          );
        }
      },
    };
  },
};

export default rule;
