function propertyName(member) {
  if (member?.type !== 'MemberExpression' || member.computed) {
    return '';
  }

  return member.property.type === 'Identifier' ? member.property.name : '';
}

function isAsyncFunction(node) {
  return (
    (node?.type === 'ArrowFunctionExpression' || node?.type === 'FunctionExpression') &&
    node.async
  );
}

const rule = {
  id: 'no-unhandled-async-listener',
  message:
    'Do not attach a raw async event listener. Use a checked handler that catches and routes errors.',
  create(context) {
    return {
      CallExpression(node) {
        if (propertyName(node.callee) !== 'addEventListener') {
          return;
        }

        if (!isAsyncFunction(node.arguments[1])) {
          return;
        }
        context.report(
          node,
          'Wrap this async listener in a checked handler that catches and routes errors.',
        );
      },
    };
  },
};

export default rule;
