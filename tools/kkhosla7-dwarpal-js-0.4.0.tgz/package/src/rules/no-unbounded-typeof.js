const BoundaryName = /^valueKind$/u;
const FeatureGlobals = new Set([
  'CompressionStream',
  'DecompressionStream',
  'DOMParser',
  'FontFace',
  'XMLSerializer',
  'browser',
  'chrome',
  'document',
  'globalThis',
  'navigator',
  'window',
]);

function comparisonValue(node, parent) {
  if (!parent || parent.type !== 'BinaryExpression') {
    return null;
  }

  if (!['==', '===', '!=', '!=='].includes(parent.operator)) {
    return null;
  }
  const other = parent.left === node ? parent.right : parent.left;
  if (other?.type !== 'Literal') {
    return null;
  }

  return other.value;
}

function isFunctionContract(node, parent) {
  if (comparisonValue(node, parent) !== 'function') {
    return false;
  }

  return node.argument.type === 'Identifier' || node.argument.type === 'MemberExpression';
}

function boundaryRanges(context, program) {
  const ranges = [];
  context.walk(program, (node) => {
    if (node.type === 'FunctionDeclaration' && BoundaryName.test(node.id?.name || '')) {
      ranges.push({ start: node.start, end: node.end });
    }
  });
  return ranges;
}

function insideBoundary(node, ranges) {
  return ranges.some((range) => node.start >= range.start && node.end <= range.end);
}

const rule = {
  id: 'no-unbounded-typeof',
  message:
    'Do not use typeof for domain decisions. Parse at the input boundary, then branch on the domain value.',
  create(context) {
    let boundaries = [];
    return {
      Program(node) {
        boundaries = boundaryRanges(context, node);
      },
      UnaryExpression(node, parent) {
        if (node.operator !== 'typeof') {
          return;
        }

        if (insideBoundary(node, boundaries)) {
          return;
        }

        if (comparisonValue(node, parent) === 'undefined') {
          return;
        }

        if (isFunctionContract(node, parent)) {
          return;
        }

        if (
          node.argument.type === 'Identifier' &&
          FeatureGlobals.has(node.argument.name)
        ) {
          return;
        }
        context.report(node, rule.message);
      },
    };
  },
};

export default rule;
