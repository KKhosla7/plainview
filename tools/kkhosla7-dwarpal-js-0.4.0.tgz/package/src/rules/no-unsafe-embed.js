const UnsafeElements = new Set(['embed', 'iframe', 'object', 'script']);
const CreateMethods = new Set(['createElement', 'createElementNS']);

function memberName(member) {
  if (member?.type !== 'MemberExpression' || member.computed) {
    return '';
  }

  return member.property.type === 'Identifier' ? member.property.name : '';
}

const rule = {
  id: 'no-unsafe-embed',
  message:
    'Do not create iframe, script, object or embed elements. Render trusted local DOM through the viewer.',
  create(context) {
    return {
      CallExpression(node) {
        if (!CreateMethods.has(memberName(node.callee))) {
          return;
        }
        const element = node.arguments[0];
        if (element?.type !== 'Literal') {
          return;
        }
        const name = String(element.value).toLocaleLowerCase();
        if (UnsafeElements.has(name)) {
          context.report(
            node,
            `Do not create <${name}>. Render trusted local DOM nodes through the viewer instead.`,
          );
        }
      },
    };
  },
};

export default rule;
