function memberName(member) {
  if (member?.type !== 'MemberExpression' || member.computed) {
    return '';
  }

  return member.property.type === 'Identifier' ? member.property.name : '';
}

const rule = {
  id: 'no-cookie-access',
  message: 'Do not access cookies. Use extension storage through the settings layer.',
  create(context) {
    return {
      MemberExpression(node) {
        const name = memberName(node);
        if (name !== 'cookie' && name !== 'cookies') {
          return;
        }
        context.report(
          node,
          'Do not read or write cookies. Use extension storage through the settings layer.',
        );
      },
    };
  },
};

export default rule;
