const Directive =
  /(biome-ignore|eslint-disable|oxlint-disable|@ts-ignore|@ts-expect-error|@ts-nocheck|prettier-ignore|nolin(t|t)|noqa|istanbul\s+ignore|c8\s+ignore|v8\s+ignore)/iu;

const rule = {
  id: 'no-suppression-directive',
  message:
    'Suppression directives are not allowed. Fix the code or use the central exceptions process.',
  create(context) {
    return {
      Program() {
        for (const comment of context.comments || []) {
          if (Directive.test(comment.value)) {
            context.report(
              { loc: comment.loc },
              rule.message,
            );
          }
        }
      },
    };
  },
};

export default rule;
