const DocumentMarkup = /(?:<!doctype|<html\b|<head\b|<body\b|<script\b|<style\b)/iu;

function textValue(node) {
  if (node.type === 'Literal') {
    return String(node.value ?? '');
  }
  if (node.type === 'TemplateElement') {
    return node.value.cooked ?? node.value.raw ?? '';
  }
  return '';
}

function isDocumentMarkup(value) {
  return DocumentMarkup.test(value);
}

const rule = {
  id: 'no-embedded-document',
  message: 'Do not embed document markup or scripts in JavaScript strings.',
  create(context) {
    function report(node, value) {
      if (isDocumentMarkup(value)) {
        context.report(
          node,
          'Move document markup and inline scripts into a template asset; keep JavaScript as orchestration only.',
        );
      }
    }

    return {
      Literal(node) {
        if (node.regex) {
          return;
        }
        report(node, textValue(node));
      },
      TemplateElement(node) {
        report(node, textValue(node));
      },
    };
  },
};

export default rule;
