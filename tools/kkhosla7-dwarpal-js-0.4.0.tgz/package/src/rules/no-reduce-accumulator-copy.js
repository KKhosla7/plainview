const CopyMethods = new Set([
  'concat',
  'slice',
  'toSpliced',
  'toSorted',
  'toReversed',
  'with',
]);

function memberName(member) {
  if (!member || member.type !== 'MemberExpression' || member.computed) {
    return '';
  }

  if (member.property.type !== 'Identifier') {
    return '';
  }

  return member.property.name;
}

function isNamedIdentifier(node, name) {
  return node?.type === 'Identifier' && node.name === name;
}

function isAccumulatorMethodCopy(child, accumulator) {
  const name = memberName(child.callee);
  return (
    Boolean(name) &&
    CopyMethods.has(name) &&
    isNamedIdentifier(child.callee.object, accumulator.name)
  );
}

function isArrayFromCopy(child, accumulator) {
  return (
    memberName(child.callee) === 'from' &&
    isNamedIdentifier(child.callee.object, 'Array') &&
    isNamedIdentifier(child.arguments[0], accumulator.name)
  );
}

function isObjectAssignCopy(child, accumulator) {
  return (
    memberName(child.callee) === 'assign' &&
    isNamedIdentifier(child.callee.object, 'Object') &&
    child.arguments[0]?.type === 'ObjectExpression' &&
    child.arguments.some((argument) => isNamedIdentifier(argument, accumulator.name))
  );
}

function isAccumulatorSpread(child, parent, accumulator) {
  return (
    child.type === 'SpreadElement' &&
    isNamedIdentifier(child.argument, accumulator.name) &&
    (parent?.type === 'ArrayExpression' || parent?.type === 'ObjectExpression')
  );
}

function isCopy(child, parent, accumulator) {
  if (child.type === 'CallExpression') {
    return (
      isAccumulatorMethodCopy(child, accumulator) ||
      isArrayFromCopy(child, accumulator) ||
      isObjectAssignCopy(child, accumulator)
    );
  }

  return isAccumulatorSpread(child, parent, accumulator);
}

const rule = {
  id: 'no-reduce-accumulator-copy',
  message: 'Mutate a fresh locally owned accumulator instead of copying it on every reduce step.',
  create(context) {
    return {
      CallExpression(node) {
        const method = memberName(node.callee);
        if (method !== 'reduce' && method !== 'reduceRight') {
          return;
        }

        const callback = node.arguments[0];
        if (!callback || !callback.params || callback.params.length === 0) {
          return;
        }
        const accumulator = callback.params[0];
        if (!accumulator || accumulator.type !== 'Identifier') {
          return;
        }

        context.walk(callback.body, (child, parent) => {
          if (isCopy(child, parent, accumulator)) {
            context.report(child, rule.message);
          }
        });
      },
    };
  },
};

export default rule;
