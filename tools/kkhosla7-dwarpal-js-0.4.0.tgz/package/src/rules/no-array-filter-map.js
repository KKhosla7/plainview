const ChainMethods = new Set(['filter', 'map']);

function propertyName(member) {
  if (!member || member.type !== 'MemberExpression' || member.computed) {
    return '';
  }

  if (member.property.type !== 'Identifier') {
    return '';
  }

  return member.property.name;
}

const rule = {
  id: 'no-array-filter-map',
  message: 'Avoid adjacent eager filter/map passes; use one pass or a lazy iterator pipeline.',
  create(context) {
    return {
      CallExpression(node) {
        const method = propertyName(node.callee);
        if (!ChainMethods.has(method)) {
          return;
        }

        const inner = node.callee.object;
        if (!inner || inner.type !== 'CallExpression') {
          return;
        }
        const innerMethod = propertyName(inner.callee);
        if (!ChainMethods.has(innerMethod) || innerMethod === method) {
          return;
        }

        context.report(node, rule.message);
      },
    };
  },
};

export default rule;
