const ControlFlow = new Set([
  'DoWhileStatement',
  'ForInStatement',
  'ForOfStatement',
  'ForStatement',
  'IfStatement',
  'ReturnStatement',
  'SwitchStatement',
  'ThrowStatement',
  'TryStatement',
  'WhileStatement',
]);

const TopLevelDeclarations = new Set([
  'ClassDeclaration',
  'FunctionDeclaration',
  'VariableDeclaration',
]);

const BlockLike = new Set([
  'BlockStatement',
  'DoWhileStatement',
  'ForInStatement',
  'ForOfStatement',
  'ForStatement',
  'IfStatement',
  'SwitchStatement',
  'TryStatement',
  'WhileStatement',
]);

function hasBlankLine(previous, current) {
  return current.loc.start.line > previous.loc.end.line + 1;
}

function isStandaloneDeclaration(node) {
  return node.type === 'ClassDeclaration' || node.type === 'FunctionDeclaration';
}

const rule = {
  id: 'require-readable-spacing',
  message: 'Expected blank line before this statement.',
  create(context) {
    function check(statements, topLevel) {
      for (let index = 1; index < statements.length; index += 1) {
        const previous = statements[index - 1];
        const current = statements[index];
        if (hasBlankLine(previous, current)) {
          continue;
        }

        if (ControlFlow.has(current.type) && BlockLike.has(previous.type)) {
          context.report(current, rule.message);
          continue;
        }

        if (
          topLevel &&
          TopLevelDeclarations.has(previous.type) &&
          TopLevelDeclarations.has(current.type) &&
          (isStandaloneDeclaration(previous) || isStandaloneDeclaration(current))
        ) {
          context.report(current, rule.message);
        }
      }
    }

    return {
      Program(node) {
        check(node.body, true);
      },
      BlockStatement(node) {
        check(node.body, false);
      },
      StaticBlock(node) {
        check(node.body, false);
      },
    };
  },
};

export default rule;
