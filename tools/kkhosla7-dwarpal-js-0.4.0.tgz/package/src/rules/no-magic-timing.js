const Timers = new Set(['setInterval', 'setTimeout']);

function memberName(member) {
  if (member?.type !== 'MemberExpression' || member.computed) {
    return '';
  }

  return member.property.type === 'Identifier' ? member.property.name : '';
}

const rule = {
  id: 'no-magic-timing',
  message:
    'Do not hardcode timer or polling delays. Use a named timing constant with a documented reason.',
  create(context) {
    return {
      CallExpression(node) {
        const name = node.callee.type === 'Identifier' ? node.callee.name : memberName(node.callee);
        if (!Timers.has(name)) {
          return;
        }
        const delay = node.arguments[1];
        if (delay?.type !== 'Literal' || !Number.isFinite(delay.value) || delay.value === 0) {
          return;
        }
        context.report(
          delay,
          `Replace the hardcoded ${delay.value}ms delay with a named timing constant.`,
        );
      },
    };
  },
};

export default rule;
