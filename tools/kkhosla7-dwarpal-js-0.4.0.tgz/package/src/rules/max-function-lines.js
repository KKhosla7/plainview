const MaxLines = 80;
const Functions = new Set([
  'ArrowFunctionExpression',
  'FunctionDeclaration',
  'FunctionExpression',
]);

const rule = {
  id: 'max-function-lines',
  message: `Functions must stay at or below ${MaxLines} lines.`,
  create(context) {
    return {
      FunctionDeclaration(node, parent) {
        check(node, parent);
      },
      FunctionExpression(node, parent) {
        check(node, parent);
      },
      ArrowFunctionExpression(node, parent) {
        check(node, parent);
      },
    };

    function check(node, parent) {
      if (!Functions.has(node.type)) {
        return;
      }
      if (parent?.type === 'CallExpression' && parent.callee === node) {
        return;
      }
      const lines = node.loc.end.line - node.loc.start.line + 1;
      if (lines > MaxLines) {
        context.report(node, `Function has ${lines} lines; maximum is ${MaxLines}.`);
      }
    }
  },
};

export default rule;
