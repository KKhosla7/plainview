const Sanitizer = /sanitize/iu;
const ReviewedSink = /^replaceWithGenerated/u;

function calleeName(callee) {
  if (callee?.type === 'Identifier') {
    return callee.name;
  }

  if (callee?.type === 'MemberExpression' && !callee.computed) {
    return callee.property.type === 'Identifier' ? callee.property.name : '';
  }

  return '';
}

function functionName(node) {
  return node.id?.name || '';
}

function functionRanges(context, program) {
  const ranges = [];
  context.walk(program, (node) => {
    if (
      node.type === 'FunctionDeclaration' ||
      node.type === 'FunctionExpression' ||
      node.type === 'ArrowFunctionExpression'
    ) {
      ranges.push({
        start: node.start,
        end: node.end,
        name: functionName(node),
        node,
      });
    }
  });
  return ranges;
}

function innermostFunction(node, ranges) {
  return ranges
    .filter((range) => node.start >= range.start && node.end <= range.end)
    .sort((left, right) => left.end - left.start - (right.end - right.start))
    .at(0);
}

function sanitizes(range, context) {
  let found = false;
  context.walk(range.node, (node) => {
    if (node.type === 'CallExpression' && Sanitizer.test(calleeName(node.callee))) {
      found = true;
    }
  });
  return found;
}

function isHtmlParse(node) {
  return (
    node.type === 'CallExpression' &&
    calleeName(node.callee) === 'parseFromString' &&
    node.arguments[1]?.type === 'Literal' &&
    node.arguments[1].value === 'text/html'
  );
}

const rule = {
  id: 'require-sanitized-markup',
  message: 'Parsed HTML must be sanitized or go through the reviewed generated-markup sink.',
  create(context) {
    let ranges = [];
    return {
      Program(node) {
        ranges = functionRanges(context, node);
      },
      CallExpression(node) {
        if (!isHtmlParse(node)) {
          return;
        }
        const owner = innermostFunction(node, ranges);
        if (owner && (ReviewedSink.test(owner.name) || sanitizes(owner, context))) {
          return;
        }
        context.report(
          node,
          'Sanitize the parsed body before insertion, or route it through replaceWithGeneratedHtml().',
        );
      },
    };
  },
};

export default rule;
