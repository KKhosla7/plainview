const MaxDepth = 4;
const MetaKeys = new Set(['loc', 'range', 'start', 'end', 'parent']);
const Nesting = new Set([
  'DoWhileStatement',
  'ForInStatement',
  'ForOfStatement',
  'ForStatement',
  'IfStatement',
  'SwitchStatement',
  'TryStatement',
  'WhileStatement',
]);
const Functions = new Set([
  'ArrowFunctionExpression',
  'FunctionDeclaration',
  'FunctionExpression',
]);

function nodeChildren(value) {
  if (Array.isArray(value)) {
    return value.filter((child) => Boolean(child?.type));
  }

  return value?.type ? [value] : [];
}

function children(node) {
  return Object.entries(node)
    .filter(([key]) => !MetaKeys.has(key))
    .flatMap(([, value]) => nodeChildren(value));
}

function isIifeWrapper(node, parent) {
  return (
    parent?.type === 'CallExpression' &&
    parent.callee === node &&
    parent.arguments.length === 0
  );
}

function reportChild(child, depth, reported, context, parent) {
  const nested = Nesting.has(child.type) && !isIifeWrapper(child, parent);
  const nextDepth = nested ? depth + 1 : depth;
  if (nested && nextDepth > MaxDepth && !reported.has(child)) {
    reported.add(child);
    context.report(child, `Nesting depth ${nextDepth} exceeds maximum ${MaxDepth}.`);
  }

  return nextDepth;
}

function visit(node, depth, reported, context, parent = null) {
  for (const child of children(node)) {
    if (Functions.has(child.type)) {
      visit(child, 0, reported, context, node);
      continue;
    }
    visit(child, reportChild(child, depth, reported, context, node), reported, context, child);
  }
}

const rule = {
  id: 'max-nesting-depth',
  message: `Nesting must stay at or below ${MaxDepth} levels.`,
  create(context) {
    return {
      Program(node) {
        visit(node, 0, new Set(), context);
      },
    };
  },
};

export default rule;
