const Replacements = new Map([
  ['attachEvent', 'addEventListener'],
  ['execCommand', 'navigator.clipboard or the Selection API'],
  ['showModalDialog', 'the <dialog> element'],
  ['unescape', 'decodeURIComponent'],
  ['escape', 'encodeURIComponent'],
]);

function memberName(member) {
  if (member?.type !== 'MemberExpression' || member.computed) {
    return '';
  }

  return member.property.type === 'Identifier' ? member.property.name : '';
}

const rule = {
  id: 'no-deprecated-dom-api',
  message: 'Use the modern replacement for deprecated browser APIs.',
  create(context) {
    return {
      CallExpression(node) {
        const name = node.callee.type === 'Identifier' ? node.callee.name : memberName(node.callee);
        const replacement = Replacements.get(name);
        if (replacement) {
          context.report(node, `Replace deprecated ${name}() with ${replacement}.`);
        }
      },
      MemberExpression(node) {
        if (memberName(node) === 'all' && node.object.type === 'Identifier' && node.object.name === 'document') {
          context.report(node, 'Replace document.all with querySelector or querySelectorAll.');
        }
      },
    };
  },
};

export default rule;
