const RemoteUrl = /^https?:\/\//iu;
const LocalHosts = new Set(['127.0.0.1', '::1', '[::1]', 'localhost']);
const NamespaceHost = 'www.w3.org';

function isRemoteUrl(value) {
  if (!RemoteUrl.test(value)) {
    return false;
  }

  try {
    const url = new URL(value);
    if (LocalHosts.has(url.hostname) || url.hostname === NamespaceHost || url.hostname === '*') {
      return false;
    }

    return true;
  } catch {
    return true;
  }
}

const rule = {
  id: 'no-remote-url',
  message:
    'Do not hardcode remote URLs. Use local resources, loopback test origins, or a reviewed protocol boundary.',
  create(context) {
    return {
      Literal(node) {
        if (!isRemoteUrl(node.value)) {
          return;
        }
        context.report(
          node,
          'Remove this remote URL. Remote access belongs behind a reviewed boundary, not a named-constant exemption.',
        );
      },
    };
  },
};

export default rule;
