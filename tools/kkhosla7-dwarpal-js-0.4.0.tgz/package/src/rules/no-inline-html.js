const HtmlProperties = new Set(['innerHTML', 'outerHTML']);

function propertyName(member) {
  if (!member || member.type !== 'MemberExpression' || member.computed) {
    return '';
  }

  return member.property.type === 'Identifier' ? member.property.name : '';
}

const rule = {
  id: 'no-inline-html',
  message:
    'Do not write raw HTML into the DOM. Build nodes with createElement/textContent or a reviewed sanitizer.',
  create(context) {
    return {
      AssignmentExpression(node) {
        if (!HtmlProperties.has(propertyName(node.left))) {
          return;
        }
        context.report(
          node,
          'Do not assign raw HTML with innerHTML/outerHTML. Use createElement and textContent.',
        );
      },
      CallExpression(node) {
        const name = propertyName(node.callee);
        if (name === 'insertAdjacentHTML') {
          context.report(
            node,
            'Do not use insertAdjacentHTML. Create nodes and insert them with append/prepend.',
          );
          return;
        }

        if (
          name === 'write' ||
          name === 'writeln'
        ) {
          const object = node.callee.object;
          if (object?.type === 'Identifier' && object.name === 'document') {
            context.report(node, 'Do not use document.write. Build and mount DOM nodes explicitly.');
          }
        }
      },
    };
  },
};

export default rule;
