const StringTimers = new Set(['setInterval', 'setTimeout']);

function calleeName(node) {
  if (node?.type === 'Identifier') {
    return node.name;
  }

  if (node?.type === 'MemberExpression' && !node.computed && node.property.type === 'Identifier') {
    return node.property.name;
  }

  return '';
}

const rule = {
  id: 'no-eval',
  message: 'Do not execute strings as code. Use a typed function or a static module import.',
  create(context) {
    return {
      CallExpression(node) {
        const name = calleeName(node.callee);
        if (name === 'eval') {
          context.report(node, 'Do not use eval. Use a typed function or a static module import.');
          return;
        }

        if (!StringTimers.has(name)) {
          return;
        }
        const callback = node.arguments[0];
        if (callback?.type === 'Literal' || callback?.type === 'TemplateLiteral') {
          context.report(
            node,
            `Do not pass strings to ${name}. Pass a function and use named constants for delays.`,
          );
        }
      },
      NewExpression(node) {
        if (calleeName(node.callee) === 'Function') {
          context.report(node, 'Do not use new Function. Use a typed function or static module code.');
        }
      },
    };
  },
};

export default rule;
