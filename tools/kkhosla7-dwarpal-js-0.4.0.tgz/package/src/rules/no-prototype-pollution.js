const ForbiddenKeys = new Set(['__proto__', 'constructor', 'prototype']);

function memberName(member) {
  if (member?.type !== 'MemberExpression') {
    return '';
  }

  if (!member.computed && member.property.type === 'Identifier') {
    return member.property.name;
  }

  return member.computed && member.property.type === 'Literal' ? String(member.property.value) : '';
}

const rule = {
  id: 'no-prototype-pollution',
  message:
    'Do not write __proto__, constructor or prototype keys. Use Object.hasOwn and null-prototype dictionaries.',
  create(context) {
    return {
      AssignmentExpression(node) {
        if (ForbiddenKeys.has(memberName(node.left))) {
          context.report(
            node,
            'Do not assign to __proto__, constructor or prototype. Use a null-prototype dictionary and Object.hasOwn.',
          );
        }
      },
      CallExpression(node) {
        const name = memberName(node.callee);
        if (name !== 'defineProperty' && name !== 'getOwnPropertyDescriptor') {
          return;
        }
        const key = node.arguments[1];
        if (key?.type === 'Literal' && ForbiddenKeys.has(String(key.value))) {
          context.report(
            node,
            'Do not access __proto__, constructor or prototype by name. Use an explicit safe schema.',
          );
        }
      },
      Property(node) {
        if (node.key.type === 'Identifier' && ForbiddenKeys.has(node.key.name)) {
          context.report(
            node,
            'Do not define __proto__, constructor or prototype properties. Use a null-prototype dictionary.',
          );
        }
      },
    };
  },
};

export default rule;
