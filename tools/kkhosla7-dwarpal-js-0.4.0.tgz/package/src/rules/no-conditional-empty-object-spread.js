function isEmptyObject(node) {
  return node?.type === 'ObjectExpression' && node.properties.length === 0;
}

const rule = {
  id: 'no-conditional-empty-object-spread',
  message:
    'Avoid conditional empty-object spreads; omission is not the same as assigning undefined.',
  create(context) {
    return {
      SpreadElement(node) {
        const argument = node.argument;
        if (argument?.type !== 'ConditionalExpression') {
          return;
        }

        if (isEmptyObject(argument.consequent) || isEmptyObject(argument.alternate)) {
          context.report(node, rule.message);
        }
      },
    };
  },
};

export default rule;
