const MaxLines = 50;
const FunctionTypes = new Set([
  'ArrowFunctionExpression',
  'FunctionDeclaration',
  'FunctionExpression',
]);

const rule = {
  id: 'max-block-lines',
  message: `Blocks must stay at or below ${MaxLines} lines.`,
  create(context) {
    return {
      BlockStatement(node, parent) {
        if (parent && FunctionTypes.has(parent.type)) {
          return;
        }
        const lines = node.loc.end.line - node.loc.start.line + 1;
        if (lines > MaxLines) {
          context.report(node, `Block has ${lines} lines; maximum is ${MaxLines}.`);
        }
      },
    };
  },
};

export default rule;
