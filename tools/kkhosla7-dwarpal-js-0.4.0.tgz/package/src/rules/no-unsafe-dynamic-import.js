function memberName(member) {
  if (member?.type !== 'MemberExpression' || member.computed) {
    return '';
  }

  return member.property.type === 'Identifier' ? member.property.name : '';
}

function isPathToFileUrlCall(node) {
  return (
    node?.type === 'CallExpression' &&
    node.callee.type === 'Identifier' &&
    node.callee.name === 'pathToFileURL'
  );
}

function isSafeSource(source) {
  if (source?.type === 'Literal') {
    return true;
  }

  if (source?.type === 'MemberExpression') {
    return memberName(source) === 'href' && isPathToFileUrlCall(source.object);
  }

  if (source?.type !== 'CallExpression') {
    return false;
  }

  if (isPathToFileUrlCall(source)) {
    return true;
  }

  return memberName(source.callee) === 'getURL';
}

const rule = {
  id: 'no-unsafe-dynamic-import',
  message:
    'Dynamic imports must use a static specifier, pathToFileURL() or a package getURL() asset path.',
  create(context) {
    return {
      ImportExpression(node) {
        if (isSafeSource(node.source)) {
          return;
        }
        context.report(
          node,
          'Do not import a computed or user-controlled path. Use a static import, pathToFileURL() or a package getURL() asset.',
        );
      },
    };
  },
};

export default rule;
