const MaxParams = 5;
const Functions = new Set([
  'ArrowFunctionExpression',
  'FunctionDeclaration',
  'FunctionExpression',
]);

const rule = {
  id: 'max-params',
  message: `Functions must have at most ${MaxParams} parameters.`,
  create(context) {
    return {
      FunctionDeclaration(node) {
        check(node);
      },
      FunctionExpression(node) {
        check(node);
      },
      ArrowFunctionExpression(node) {
        check(node);
      },
    };

    function check(node) {
      if (!Functions.has(node.type) || node.params.length <= MaxParams) {
        return;
      }
      context.report(
        node,
        `Function has ${node.params.length} parameters; maximum is ${MaxParams}.`,
      );
    }
  },
};

export default rule;
