const rule = {
  id: 'no-insecure-random',
  message:
    'Do not use Math.random for identifiers or security-sensitive values. Use crypto.getRandomValues or crypto.randomUUID.',
  create(context) {
    return {
      CallExpression(node) {
        const callee = node.callee;
        if (
          callee.type === 'MemberExpression' &&
          !callee.computed &&
          callee.object.type === 'Identifier' &&
          callee.object.name === 'Math' &&
          callee.property.type === 'Identifier' &&
          callee.property.name === 'random'
        ) {
          context.report(
            node,
            'Replace Math.random() with crypto.getRandomValues() or crypto.randomUUID().',
          );
        }
      },
    };
  },
};

export default rule;
