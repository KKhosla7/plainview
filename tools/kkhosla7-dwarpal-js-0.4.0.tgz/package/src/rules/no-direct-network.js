const NetworkCalls = new Set(['fetch', 'sendBeacon']);
const NetworkConstructors = new Set(['EventSource', 'WebSocket', 'XMLHttpRequest']);
const BoundaryName = /^requestSource(?:[A-Z]|$)/u;

function memberName(member) {
  if (member?.type !== 'MemberExpression' || member.computed) {
    return '';
  }

  return member.property.type === 'Identifier' ? member.property.name : '';
}

function calleeName(callee) {
  return callee?.type === 'Identifier' ? callee.name : memberName(callee);
}

function boundaryRanges(context, program) {
  const ranges = [];
  context.walk(program, (node) => {
    if (node.type === 'FunctionDeclaration' && BoundaryName.test(node.id?.name || '')) {
      ranges.push({ start: node.start, end: node.end });
    }
  });
  return ranges;
}

function insideBoundary(node, ranges) {
  return ranges.some((range) => node.start >= range.start && node.end <= range.end);
}

const rule = {
  id: 'no-direct-network',
  message:
    'Do not make network requests directly. Route them through one reviewed requestSource() boundary with validated URLs.',
  create(context) {
    let boundaries = [];
    function report(node, message) {
      if (!insideBoundary(node, boundaries)) {
        context.report(node, message);
      }
    }
    return {
      Program(node) {
        boundaries = boundaryRanges(context, node);
      },
      CallExpression(node) {
        const name = calleeName(node.callee);
        if (NetworkCalls.has(name)) {
          report(
            node,
            `Replace direct ${name}() with a reviewed requestSource() boundary and validated URLs.`,
          );
        }
      },
      NewExpression(node) {
        const name = calleeName(node.callee);
        if (NetworkConstructors.has(name)) {
          report(
            node,
            `Replace new ${name}() with a reviewed requestSource() boundary and validated URLs.`,
          );
        }
      },
    };
  },
};

export default rule;
