const MaxStatements = 25;

const rule = {
  id: 'max-statements-per-block',
  message: `Blocks must contain at most ${MaxStatements} statements.`,
  create(context) {
    return {
      BlockStatement(node) {
        check(node);
      },
      StaticBlock(node) {
        check(node);
      },
    };

    function check(node) {
      if (node.body.length > MaxStatements) {
        context.report(
          node,
          `Block has ${node.body.length} statements; maximum is ${MaxStatements}.`,
        );
      }
    }
  },
};

export default rule;
