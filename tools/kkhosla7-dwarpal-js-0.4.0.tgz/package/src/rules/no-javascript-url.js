const ScriptUrl = /^\s*(?:javascript|vbscript):/iu;

const rule = {
  id: 'no-javascript-url',
  message:
    'Do not allow javascript: or vbscript: URLs. Use validated http(s), file, mailto or anchor URLs.',
  create(context) {
    return {
      Literal(node) {
        if (!ScriptUrl.test(node.value)) {
          return;
        }
        context.report(node, 'Replace this script URL with a validated http(s), file or anchor URL.');
      },
    };
  },
};

export default rule;
