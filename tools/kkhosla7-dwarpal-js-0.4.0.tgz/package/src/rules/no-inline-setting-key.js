const SettingKey = /^(?:plainview|mdview)\./u;
const NamedKey = /(?:Key|Keys|Prefix)$/u;

function allowedRanges(context, program) {
  const ranges = [];
  context.walk(program, (node) => {
    if (
      node.type === 'VariableDeclarator' &&
      node.id.type === 'Identifier' &&
      NamedKey.test(node.id.name) &&
      node.init?.type === 'Literal' &&
      SettingKey.test(node.init.value)
    ) {
      ranges.push({ start: node.init.start, end: node.init.end });
    }
  });
  return ranges;
}

function isAllowed(node, ranges) {
  return ranges.some((range) => node.start >= range.start && node.end <= range.end);
}

const rule = {
  id: 'no-inline-setting-key',
  message: 'Do not inline extension storage keys. Import them from the settings key registry.',
  create(context) {
    let ranges = [];
    return {
      Program(node) {
        ranges = allowedRanges(context, node);
      },
      Literal(node) {
        if (!SettingKey.test(node.value) || isAllowed(node, ranges)) {
          return;
        }
        context.report(
          node,
          'Move this storage key into a named *Key or *Prefix constant and reuse it everywhere.',
        );
      },
    };
  },
};

export default rule;
