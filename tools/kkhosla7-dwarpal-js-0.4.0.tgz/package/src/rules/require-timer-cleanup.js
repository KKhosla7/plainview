function propertyName(member) {
  if (member?.type !== 'MemberExpression' || member.computed) {
    return '';
  }

  return member.property.type === 'Identifier' ? member.property.name : '';
}

function callName(callee) {
  return callee?.type === 'Identifier' ? callee.name : propertyName(callee);
}

function isTimerCall(node, name) {
  return node.type === 'CallExpression' && callName(node.callee) === name;
}

const rule = {
  id: 'require-timer-cleanup',
  message: 'Store intervals and clear them during teardown.',
  create(context) {
    return {
      Program(program) {
        const cleared = new Set();
        const intervals = [];
        context.walk(program, (node) => {
          if (!isTimerCall(node, 'clearInterval')) {
            return;
          }
          const timer = node.arguments[0];
          if (timer?.type === 'Identifier') {
            cleared.add(timer.name);
          }
        });
        context.walk(program, (node, parent) => {
          if (!isTimerCall(node, 'setInterval')) {
            return;
          }
          const stored =
            parent?.type === 'VariableDeclarator' &&
            parent.id.type === 'Identifier' &&
            cleared.has(parent.id.name);
          if (!stored) {
            context.report(node, 'Assign the interval to a timer and call clearInterval() on teardown.');
          }
        });
      },
    };
  },
};

export default rule;
