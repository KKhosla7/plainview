import { parseJavaScript } from './parser.js';

export const languagePack = Object.freeze({
	id: 'js',
	extensions: Object.freeze(['.js', '.jsx', '.mjs', '.cjs', '.ts', '.tsx']),
	implies: Object.freeze([]),
	capabilities: Object.freeze({ syntax: true }),
	parse: parseJavaScript
});

export const languages = [languagePack];
